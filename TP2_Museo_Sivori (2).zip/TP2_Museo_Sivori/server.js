import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const staticDir = path.join(__dirname, 'museo_v1');

// Support lowercase "imagenes/", capitalized "Imagenes/", and legacy "assets/" paths on Linux
app.use('/assets/aistudio', express.static(path.join(__dirname, 'public', 'assets', 'aistudio')));
app.use('/imagenes', express.static(path.join(staticDir, 'Imagenes')));
app.use('/assets', express.static(path.join(staticDir, 'Imagenes')));
app.use(express.static(staticDir));

app.use((req, res) => {
  res.sendFile(path.join(staticDir, 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Museo Sívori static server listening on http://0.0.0.0:${PORT}`);
});
