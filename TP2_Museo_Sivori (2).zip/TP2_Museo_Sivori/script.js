// Navegación mobile y formulario de Amigos.
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('menuToggle');
  const menu = document.getElementById('mainNavigation');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      const isOpen = menu.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      toggle.setAttribute('aria-label', isOpen ? 'Cerrar menú' : 'Abrir menú');
      toggle.textContent = isOpen ? '✕' : '☰';
    });
    menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      menu.classList.remove('open');
      toggle.setAttribute('aria-expanded', 'false');
      toggle.setAttribute('aria-label', 'Abrir menú');
      toggle.textContent = '☰';
    }));
  }

  const form = document.getElementById('membershipForm');
  if (!form) return;

  const split = document.querySelector('#asociarme .split');
  const timeline = document.querySelector('#asociarme .timeline');
  const nameInput = document.getElementById('membershipName');
  const mailInput = document.getElementById('membershipMail');
  const planSelect = document.getElementById('membershipPlan');
  const submitBtn = document.getElementById('membershipSubmitBtn');
  const formMessage = document.getElementById('formMessage');
  const modalCard = document.getElementById('modalNotificationCard');
  const modalIcon = document.getElementById('modalNotificationIcon');
  const modalKicker = document.getElementById('modalNotificationKicker');
  const modalTitle = document.getElementById('modalNotificationTitle');
  const modalBody = document.getElementById('modalNotificationBody');
  const modalEmailSimBox = document.getElementById('modalEmailSimBox');
  const modalPrimaryBtn = document.getElementById('modalPrimaryBtn');
  const modalSecondaryBtn = document.getElementById('modalSecondaryBtn');
  const closeBtn = document.getElementById('closeFormMessageBtn');

  const emailPreviewTo = document.getElementById('emailPreviewTo');

  const syncStepperAlignment = () => {
    if (!split || !timeline) return;
    form.style.marginTop = '';
    timeline.style.minHeight = '';

    if (window.innerWidth <= 720) return;

    const offset = Math.max(0, Math.round(timeline.getBoundingClientRect().top - split.getBoundingClientRect().top));
    form.style.marginTop = `${offset}px`;
    timeline.style.minHeight = `${Math.round(form.getBoundingClientRect().height)}px`;
  };

  window.addEventListener('resize', () => requestAnimationFrame(syncStepperAlignment));
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => requestAnimationFrame(syncStepperAlignment));
  }
  requestAnimationFrame(syncStepperAlignment);

  let isSubmitting = false;
  let activeFocusTarget = null;

  const iconPaths = {
    success: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5" /></svg>',
    warning: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 8v5" /><circle cx="12" cy="16.5" r=".7" fill="currentColor" stroke="none" /></svg>'
  };

  const closeModal = (resetForm = false) => {
    if (formMessage) formMessage.hidden = true;
    if (resetForm) {
      form.reset();
      if (submitBtn) {
        submitBtn.dataset.submitted = 'false';
        submitBtn.disabled = false;
        submitBtn.textContent = 'Inscribirme';
      }
      nameInput?.focus();
    } else if (activeFocusTarget) {
      activeFocusTarget.focus();
    }
    activeFocusTarget = null;
  };

  const openModal = ({ type, kicker, title, bodyText, showSim, primaryLabel, secondaryLabel, focusTarget }) => {
    if (!formMessage || !modalCard) return;

    modalCard.classList.remove('is-success', 'is-warning', 'is-error', 'is-info');
    modalCard.classList.add(`is-${type}`);

    if (modalIcon) modalIcon.innerHTML = iconPaths[type] || iconPaths.success;
    if (modalKicker) modalKicker.textContent = kicker;
    if (modalTitle) modalTitle.textContent = title;
    if (modalBody) modalBody.textContent = bodyText;
    if (modalEmailSimBox) modalEmailSimBox.hidden = !showSim;

    if (modalPrimaryBtn) modalPrimaryBtn.textContent = primaryLabel;
    if (modalSecondaryBtn) {
      modalSecondaryBtn.hidden = !secondaryLabel;
      if (secondaryLabel) modalSecondaryBtn.textContent = secondaryLabel;
    }

    activeFocusTarget = focusTarget || null;
    formMessage.hidden = false;
    modalPrimaryBtn?.focus();
  };

  // Permitir volver a enviar si el usuario edita los datos después de un envío
  [nameInput, mailInput, planSelect].forEach(el => {
    const resetSubmittedFlag = () => {
      if (submitBtn && submitBtn.dataset.submitted === 'true') {
        submitBtn.dataset.submitted = 'false';
        submitBtn.disabled = false;
      }
    };
    el?.addEventListener('input', resetSubmittedFlag);
    el?.addEventListener('change', resetSubmittedFlag);
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    if (isSubmitting || submitBtn?.dataset.submitted === 'true') return;

    const enteredName = nameInput?.value.trim() || '';
    const enteredMail = mailInput?.value.trim() || '';
    const enteredPlan = planSelect?.value.trim() || '';
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

    if (!enteredName) {
      openModal({
        type: 'warning',
        kicker: 'Atención',
        title: 'Revisá los datos antes de continuar.',
        bodyText: 'Ingresá tu nombre para que podamos registrar tu solicitud de inscripción.',
        showSim: false,
        primaryLabel: 'Completar nombre',
        secondaryLabel: '',
        focusTarget: nameInput
      });
      return;
    }

    if (!enteredMail || !emailPattern.test(enteredMail)) {
      openModal({
        type: 'warning',
        kicker: 'Atención',
        title: 'Revisá los datos antes de continuar.',
        bodyText: 'Ingresá una dirección de correo electrónico válida para preparar la confirmación.',
        showSim: false,
        primaryLabel: 'Corregir correo',
        secondaryLabel: '',
        focusTarget: mailInput
      });
      return;
    }

    if (!enteredPlan) {
      openModal({
        type: 'warning',
        kicker: 'Atención',
        title: 'Revisá los datos antes de continuar.',
        bodyText: 'Elegí un plan de membresía para completar tu solicitud de inscripción.',
        showSim: false,
        primaryLabel: 'Elegir plan',
        secondaryLabel: '',
        focusTarget: planSelect
      });
      return;
    }

    isSubmitting = true;
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.textContent = 'Registrando...';
    }

    window.setTimeout(() => {
      isSubmitting = false;

      if (emailPreviewTo) emailPreviewTo.textContent = enteredMail;

      if (submitBtn) {
        submitBtn.dataset.submitted = 'true';
        submitBtn.textContent = 'Inscribirme';
        submitBtn.disabled = true;
      }

      openModal({
        type: 'success',
        kicker: 'Amigos',
        title: '¡Listo! Tu solicitud se registró correctamente.',
        bodyText: `Hola ${enteredName}, recibimos tus datos para el plan ${enteredPlan}. En breve recibirás los próximos pasos para sumarte a Amigos.`,
        showSim: true,
        primaryLabel: 'Entendido',
        secondaryLabel: 'Nueva solicitud',
        focusTarget: null
      });
    }, 350);
  });

  modalPrimaryBtn?.addEventListener('click', () => closeModal(false));
  modalSecondaryBtn?.addEventListener('click', () => closeModal(true));
  closeBtn?.addEventListener('click', () => closeModal(false));

  formMessage?.addEventListener('click', (event) => {
    if (event.target === formMessage) closeModal(false);
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && formMessage && !formMessage.hidden) {
      closeModal(false);
    }
  });
});

// Flores que crecen al hover, foco de teclado y toque en pantallas táctiles.
document.addEventListener('DOMContentLoaded', () => {
  const blooms = document.querySelectorAll('.bloom-spot');
  blooms.forEach(button => {
    button.addEventListener('click', () => {
      const active = button.classList.toggle('is-blooming');
      button.setAttribute('aria-pressed', String(active));
    });
  });

  // Mapa interactivo del Museo en visitar.html
  const mapEl = document.getElementById('sivoriMap');
  if (mapEl && typeof window.L !== 'undefined') {
    const sivoriCoords = [-34.56892, -58.41787];
    const map = window.L.map(mapEl, {
      center: sivoriCoords,
      zoom: 16,
      minZoom: 13,
      maxZoom: 19,
      zoomControl: false,
      dragging: true,
      inertia: false,
      touchZoom: true,
      doubleClickZoom: true,
      scrollWheelZoom: true
    });

    window.L.control.zoom({
      position: 'topleft',
      zoomInTitle: 'Acercar mapa',
      zoomOutTitle: 'Alejar mapa'
    }).addTo(map);

    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap',
      maxZoom: 19
    }).addTo(map);

    const markerIcon = window.L.divIcon({
      className: 'sivori-marker-wrap',
      html: '<span class="sivori-marker-pulse" aria-hidden="true"></span><span class="sivori-marker-pin" aria-hidden="true"><svg viewBox="0 0 36 44" width="36" height="44" focusable="false"><path d="M18 1C8.611 1 1 8.611 1 18c0 11.75 15.14 23.62 16.05 24.33a1.55 1.55 0 0 0 1.9 0C19.86 41.62 35 29.75 35 18 35 8.611 27.389 1 18 1Z" fill="#7d3349" stroke="#fdf9f2" stroke-width="2"/><circle cx="18" cy="17.5" r="7.2" fill="#fdf9f2"/><circle cx="18" cy="17.5" r="3.4" fill="#a5506a"/></svg></span>',
      iconSize: [36, 44],
      iconAnchor: [18, 43],
      popupAnchor: [0, -38]
    });

    const marker = window.L.marker(sivoriCoords, {
      icon: markerIcon,
      title: 'Museo de Artes Plásticas · Av. Infanta Isabel 555',
      alt: 'Ubicación del Museo de Artes Plásticas'
    }).addTo(map);

    marker.bindPopup(
      '<div class="sivori-popup-card">' +
        '<div class="sivori-popup-tag">Parque Tres de Febrero · Frente al Rosedal</div>' +
        '<h4 class="sivori-popup-title">Museo de Artes Plásticas</h4>' +
        '<p class="sivori-popup-address">Av. Infanta Isabel 555, Palermo, Buenos Aires, Argentina.</p>' +
        '<a class="sivori-popup-link" href="https://share.google/iSf3S1qDqrLIA5qLo" target="_blank" rel="noopener noreferrer">Abrir en Google Maps</a>' +
      '</div>',
      {
        maxWidth: 255,
        minWidth: 215,
        className: 'sivori-map-popup',
        autoPanPaddingTopLeft: [24, 24],
        autoPanPaddingBottomRight: [24, 24]
      }
    );

    window.addEventListener('load', () => map.invalidateSize());
    if (typeof window.ResizeObserver !== 'undefined') {
      new window.ResizeObserver(() => map.invalidateSize()).observe(mapEl);
    }
  }
});
